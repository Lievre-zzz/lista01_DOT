def num_perfeito(a):
    divisores = 0

    for c in range(1, a):
        if a % c == 0:
            divisores += c

    if divisores == a:
        return True
    else:
        return False


def main():
    num = int(input('Digite um número: \n'))

    resposta = num_perfeito(num)

    if resposta is True:
        print('O número é perfeito.')
    else:
        print('O número não é perfeito.')


if __name__ == '__main__':
    main()
