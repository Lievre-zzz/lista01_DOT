'''lista02_q01'''
from random import randint


def aleatorio(a):
    for c in range(0, 100):
        a.append(randint(0, 100))

    return a


def pares(a):
    num_pares = []
    qnt_pares = 0

    for c in a:
        if c % 2 == 0:
            num_pares.append(c)
            qnt_pares += 1

    return qnt_pares, num_pares


def impares(a):
    num_impares = []
    qnt_impares = 0

    for c in a:
        if c % 2 == 1:
            num_impares.append(c)
            qnt_impares += 1

    return qnt_impares, num_impares


def main():
    lista = []
    lista = aleatorio(lista)

    qnt_pares, num_pares = pares(lista)
    qnt_impares, num_impares = impares(lista)

    print(f'A lista tem {qnt_pares} números pares, sendo eles: ', end='')
    for c in num_pares:
        print(c, end=' - ')

    print()
    print(f'A lista tem {qnt_impares} números ímpares, sendo eles: ', end='')
    for c in num_impares:
        print(c, end=' - ')


if __name__ == '__main__':
    main()
