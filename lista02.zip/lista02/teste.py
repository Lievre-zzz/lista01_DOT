lista = [1, 2, 3, 4, 5]
inverso = []

for c in lista:
    inverso.insert(0, c)

print(lista)
print(inverso)
