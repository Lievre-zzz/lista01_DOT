'''lista01_q6: triangulo, quadrado ou pentágono'''


def poligono(a, b):
    if a == 3:
        print(f'O polígono é um triângulo com perímetro de {b * 3} centímetros.')

    elif a == 4:
        print(f'O polígono é um quadrado com área de {b * b} cm².')

    else:
        print('O polígono é um pentágono.')


def main():
    nlados = int(input('Digite o número de lados do polígono (apenas 3, 4 ou 5):\n'))

    while nlados < 3 or nlados > 5:
        nlados = int(input('Valor inválido! Tente novamente.\n'))

    tamlado = float(input('Digite a medida do lado deste polígono (em centímetros):\n'))

    while tamlado < 0:
        tamlado = float(input('Valor inválido! Tente novamente.\n'))

    poligono(nlados, tamlado)


if __name__ == '__main__':
    main()
