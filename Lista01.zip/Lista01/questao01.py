'''Lista1_q1: Faça uma função que recebe um número inteiro por parâmetro e retorna verdadeiro se ele for par e falso se
ele for ímpar.'''


def par_impar(a):
    touf = a % 2 == 0
    if touf is True:
        print('O número é par.')
    else:
        print('O número é ímpar.')


def main():
    num = int(input('Digite um número inteiro e positivo:\n'))

    while num <= 0:
        num = int(input('Valor inválido! Tente novamente.\n'))

    par_impar(num)


if __name__ == '__main__':
    main()
