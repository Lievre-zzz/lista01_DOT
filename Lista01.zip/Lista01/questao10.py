'''lista01_q10: Escreva um programa composto de uma função Max e o programa principal como segue:
a) A função Max recebe como parâmetros de entrada dois números inteiros e retorna o maior. Se forem iguais retorna qualquer um
deles;
b) O programa principal lê 4 séries de 4 números a, b. Para cada série lida imprime o maior dos quatro números usando a função
Max.'''


def main():
    lista = []

    for c in range(1, 5):
        print(f'SÉRIE {c}\n')

        for cont in range(1, 5):
            lista.append(int(input(f'Digite o número {cont} da lista:\n')))

        print(f'O maior valor da lista é {max(lista)}.\n')
        print('-=' * 15)
        lista.clear()


if __name__ == '__main__':
    main()
