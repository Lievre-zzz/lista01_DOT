'''lista01_q10'''


def main():
    lista = []

    for c in range(1, 5):
        print(f'SÉRIE {c}\n')

        for cont in range(1, 5):
            lista.append(int(input(f'Digite o número {cont} da lista:\n')))

        print(f'O maior valor da lista é {max(lista)}.\n')
        print('-=' * 15)
        lista.clear()


if __name__ == '__main__':
    main()
