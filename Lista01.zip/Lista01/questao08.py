'''lista1_q8'''


def cubo(a):
    return a * a * a


def main():
    while True:
        num = int(input('Digite um número:\n'))
        print(f'O número digitado elevado ao cubo é {cubo(num)}.')

        continuar = input('Deseja continuar? [S/N]\n')

        while continuar.upper() != 'S' and continuar.upper() != 'N':
            continuar = input('Caractere inválido! Tente novamente.\n')

        if continuar.upper() == 'S':
            continue
        else:
            print('Fim do programa.')
            break


if __name__ == '__main__':
    main()
