'''lista1_q8: ler um número e retornar o cubo desse número. depois, ler um valor chave s ou n que define se o programa irá continuar ou não'''


def cubo(a):
    return a * a * a


def main():
    while True:
        num = int(input('Digite um número:\n'))
        print(f'O número digitado elevado ao cubo é {cubo(num)}.')

        continuar = input('Deseja continuar? [S/N]\n')

        while continuar.upper() != 'S' and continuar.upper() != 'N':
            continuar = input('Caractere inválido! Tente novamente.\n')

        if continuar.upper() == 'S':
            continue
        else:
            print('Fim do programa.')
            break


if __name__ == '__main__':
    main()
