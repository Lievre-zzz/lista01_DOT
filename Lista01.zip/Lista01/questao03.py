'''Lista1_q3: Conversor celsius-fahrenheit'''


def conversor(a):
    return ((a - 32) / 9) * 5


def main():
    tf = float(input('Digite a temperatura em Fahrenheit:\n'))

    print(f'A temperatura vale {conversor(tf):.1f}ºC.')


if __name__ == '__main__':
    main()














