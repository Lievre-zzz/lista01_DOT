'''lista1_q7: calcular o fatorial de um número'''


def fatorial(a):
    for c in range(1, a):
        a *= c

    return a


def main():
    num = int(input('Digite um número inteiro, positivo e maior que zero:\n'))

    while num <= 0:
        num = int(input('Valor inválido! Tente novamente.\n'))

    res = fatorial(num)

    print(f'O fatorial do número digitado é {res}.')


if __name__ == '__main__':
    main()
