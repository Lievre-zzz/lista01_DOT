'''lista01_q11: 11. Faça uma função que recebe, por parâmetro, um valor inteiro e positivo e retorna o número de divisores desse valor.'''


def divisores(a):
    divs = 0
    for c in range(1, a + 1):
        if a % c == 0:
            divs += 1

    return divs


def main():
    num = int(input('Digite um número inteiro e positivo:\n'))

    while num < 0:
        num = int(input('Valor inválido! Tente novamente:\n'))

    divs = divisores(num)

    print(f'O número de divisores do valor digitado é {divs}.')


if __name__ == '__main__':
    main()
