'''lista01_q15'''


def formula(a):
    s = 0

    for c in range(1, a + 1):
        s += (c * c + 1) / (c + 3)

    return s


def main():
    num = int(input('Digite um valor inteiro e positivo:\n'))

    while num <= 0:
        num = int(input('Valor inválido! Tente novamente.\n'))

    resultado = formula(num)

    print(f'O resultado da fórmula com o valor digitado é {resultado:.2f}.')


if __name__ == '__main__':
    main()
