'''lista01_q15: Escreva uma função que recebe por parâmetro um valor inteiro e positivo N e retorna o valor de S.
S = 2/4 + 5/5 + 10/6 + 17/7 + 26/8 + ... +(t^2+1)/(t+3)'''


def formula(a):
    s = 0
    t = 1

    for c in range(0, a):
        s += (t * t + 1) / (t + 3)
        t += 1

    return s


def main():
    num = int(input('Digite um número inteiro maior que 0:\n'))

    while num <= 0:
        num = int(input('Valor inválido! Tente novamente.\n'))

    s = formula(num)

    print(f'O resultado da fórmula com o valor selecionado é {s:.2f}.')


if __name__ == '__main__':
    main()
