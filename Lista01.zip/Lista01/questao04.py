'''Lista01_q4: media de duas notas de um aluno'''


def media(a, b):
    return (a + b) / 2


def main():
    n1 = float(input('Digite a primeira nota:\n'))

    while n1 < 0 or n1 > 10:
        n1 = float(input('Valor inválido! Tente novamente.\n'))

    n2 = float(input('Digite a segunda nota:\n'))

    while n2 < 0 or n2 > 10:
        n2 = float(input('Valor inválido! Tente novamente.\n'))

    med = media(n1, n2)

    if med >= 6:
        print('PARABÉNS! Você foi aprovado!')
    else:
        print('Você foi reprovado.')


if __name__ == '__main__':
    main()












