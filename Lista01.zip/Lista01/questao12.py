'''lista01_q12'''


def somatorio(a):
    s = 0

    for c in range(0, a + 1):
        s += c

    return s


def main():
    num = int(input('Digite um número inteiro e positivo:\n'))

    while num < 0:
        num = int(input('Valor inválido! Tente novamente.\n'))

    s = somatorio(num)

    print(f'O somatório do número digitado é {s}.')


if __name__ == '__main__':
    main()
