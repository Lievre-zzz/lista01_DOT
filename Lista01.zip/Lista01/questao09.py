'''lista01_q09'''


def soma(a, b):
    s = 0

    for c in range(a, b + 1):
        s += c

    return s


def main():
    num1 = int(input('Digite um número:\n'))
    num2 = int(input('Digite outro número:\n'))

    while num2 >= num1:
        num2 = int(input('O segundo valor deve ser maior que o primeiro! Tente novamente.\n'))

    s = soma(num1, num2)

    print(f'A soma de todos os números inteiros contidos no intervalo entre o primeiro e o segundo números é {s}.')


if __name__ == '__main__':
    main()
