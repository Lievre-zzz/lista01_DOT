'''Lista1_q2: Ler o raio do círculo e retornar a área e o perimetro.'''


def area(a):
    return 3.14 * (a * a)


def perimetro(a):
    return 3.14 * 2 * a


def main():
    raio = float(input('Digite o raio do círculo:\n'))

    while raio <= 0:
        raio = float(input('Valor inválido! Tente novamente.\n'))

    print(f'A área do círculo é {area(raio):.2f} cm².')
    print(f'O perímetro do círculo é {perimetro(raio):.2f} cm.')


if __name__ == '__main__':
    main()






















