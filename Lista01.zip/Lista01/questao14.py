'''lista01_q14'''


def fatorial(a):
    for c in range(1, a):
        a *= c

    return a


def formula(a):
    s = 0

    for c in range(1, a + 1):
        s += 1 / fatorial(c)

    return s


def main():
    num = int(input('Digite um valor inteiro e positivo:\n'))

    while num <= 0:
        num = int(input('Valor inválido! Tente novamente.\n'))

    s = formula(num)

    print(f'O resultado da fórmula com o valor digitado é {s:.2f}.')


if __name__ == '__main__':
    main()
