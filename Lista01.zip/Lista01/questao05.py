'''Lista01_q5: peso ideal é minha pica de chapéu'''


def peso(a, b):
    if a == 1:
        return (72.7 * b) - 58
    else:
        return (62.1 * b) - 44.7


def main():
    sexo = int(input('Qual o seu sexo? (1 - Masculino / 2 - Feminino)\n'))

    while sexo < 1 or sexo > 2:
        sexo = int(input('Valor inválido! Tente novamente.\n'))

    altura = float(input('Digite sua altura (em metros):\n'))

    while altura < 1 or altura > 2.5:
        altura = float(input('Valor inválido! Tente novamente.\n'))

    print(f'O seu "peso ideal" é {peso(sexo, altura):.1f} KG.')


if __name__ == '__main__':
    main()
