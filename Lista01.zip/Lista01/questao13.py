'''lista01_questao13> Escreva uma função que recebe por parâmetro um valor inteiro e positivo N e retorna o valor de S.
S = 1 + ½ + 1/3 + ¼ + 1/5 + 1/N.'''


def formula(a):
    s = 0

    for c in range(1, a + 1):
        s += 1 / c

    return s


def main():
    num = int(input('Digite um valor inteiro e positivo:\n'))

    while num <= 0:
        num = int(input('Valor inválido! Tente novamente.\n'))

    s = formula(num)

    print(f'O resultado da fórmula com o número digitado é {s:.2f}.')


if __name__ == '__main__':
    main()

